package com.example.tugas3kelasa

import android.R
import android.annotation.SuppressLint
import android.database.Cursor
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var pegawaiAdapter: PegawaiAdapter
    private lateinit var pegawaiList: MutableList<Pegawai>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val namaEditText = findViewById<EditText>(R.id.namaEditText)
        val nipEditText = findViewById<EditText>(R.id.nipEditText)
        val addButton = findViewById<Button>(R.id.addButton)
        recyclerView = findViewById(R.id.recyclerView)
        databaseHelper = DatabaseHelper(this)
        pegawaiList = ArrayList()

        recyclerView.layoutManager = LinearLayoutManager(this)

        // Ambil semua data dari database dan tampilkan
        loadPegawaiData()

        addButton.setOnClickListener {
            val nama = namaEditText.text.toString()
            val nip = nipEditText.text.toString()

            if (nama.isNotEmpty() && nip.isNotEmpty()) {
                // Tambahkan pegawai ke database
                val inserted = databaseHelper.addPegawai(nama, nip)
                if (inserted) {
                    Toast.makeText(this, "Pegawai ditambahkan", Toast.LENGTH_SHORT).show()
                    // Bersihkan input
                    namaEditText.text.clear()
                    nipEditText.text.clear()
                    // Perbarui data yang ditampilkan
                    loadPegawaiData()
                } else {
                    Toast.makeText(this, "Gagal menambahkan pegawai", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Isi semua field", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @SuppressLint("Range")
    private fun loadPegawaiData() {
        pegawaiList.clear()
        val cursor = databaseHelper.allPegawai
        if (cursor.moveToFirst()) {
            do {
                val nama = cursor.getString(cursor.getColumnIndex("nama"))
                val nip = cursor.getString(cursor.getColumnIndex("nip"))
                pegawaiList.add(Pegawai(nama, nip))
            } while (cursor.moveToNext())
        }
        cursor.close()

        pegawaiAdapter = PegawaiAdapter(pegawaiList)
        recyclerView.adapter = pegawaiAdapter
    }
}
