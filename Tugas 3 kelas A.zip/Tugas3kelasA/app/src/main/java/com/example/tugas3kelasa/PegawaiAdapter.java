package com.example.tugas3kelasa;

public class PegawaiAdapter extends RecyclerView.Adapter<PegawaiAdapter.PegawaiViewHolder> {
    private List<Pegawai> pegawaiList;

    public PegawaiAdapter(List<Pegawai> pegawaiList) {
        this.pegawaiList = pegawaiList;
    }

    @NonNull
    @Override
    public PegawaiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pegawai, parent, false);
        return new PegawaiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PegawaiViewHolder holder, int position) {
        Pegawai pegawai = pegawaiList.get(position);
        holder.namaTextView.setText(pegawai.getNama());
        holder.nipTextView.setText(pegawai.getNip());
    }

    @Override
    public int getItemCount() {
        return pegawaiList.size();
    }

    public static class PegawaiViewHolder extends RecyclerView.ViewHolder {
        TextView namaTextView, nipTextView;

        public PegawaiViewHolder(@NonNull View itemView) {
            super(itemView);
            namaTextView = itemView.findViewById(R.id.namaTextView);
            nipTextView = itemView.findViewById(R.id.nipTextView);
        }
    }
}

