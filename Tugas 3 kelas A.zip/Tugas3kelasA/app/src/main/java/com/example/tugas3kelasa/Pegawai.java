package com.example.tugas3kelasa;

public class Pegawai {
    private String nama;
    private String nip;

    public Pegawai(String nama, String nip) {
        this.nama = nama;
        this.nip = nip;
    }

    public String getNama() {
        return nama;
    }

    public String getNip() {
        return nip;
    }
}
